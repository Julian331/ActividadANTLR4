grammar Hello;
r : 'hello' ID ;
ID : [a-z]+ ;
WS : [ \r\n\t]+ -> skip ;
